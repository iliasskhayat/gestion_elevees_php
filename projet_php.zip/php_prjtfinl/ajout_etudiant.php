
    
<link rel="stylesheet" href="su.css">


<table>
<form action="ajout_etudiant.php" method="POST" enctype="multipart/form-data" >
   <!-- <p> welcome to create a new account</p> -->
  <table align="center">
      <tr>  
          <th>CNE</th>
          <td > <b>:</b><input class="upp" type="text" name="cne" Placeholder="CNE" ></td>
      </tr>
      
      <tr>
          <th>NOM</th>
          <td> <b>:</b><input class="upp" type="text" name="eduntifiant"  Placeholder=" LAST_NAME"></td>
      </tr>
      <tr>
          <th>PRENOM</th>
          <td> <b>:</b><input class="upp" type="text" name="prenom" Placeholder=" FIRST_NAME"></td>
      </tr>
      <tr>
         <th>EMIAIL</th>
         <td > <b>:</b><input  class="upp" type="email" name="emo" Placeholder=" EMAIL "> </td>
      </tr>
      <tr> 
          <th>PHOTO</th>
         <td> <b>:</b>  <input class="upp" type="file"  name="image" id="im"></td>
        </tr>
        
  </table>
     <table align="center">
          <tr>
              <td><button type=""submit name="ok"> AJOUTER </button></td>
          </tr>
     </table>
</form>
</table>
<?php

    
    if(isset($_POST["ok"])):
        require_once "connect_to_server.php";
        $cne_getting=$_POST["cne"];
        $eduntifiant_getting=$_POST["eduntifiant"];
        $prenom_getting=$_POST["prenom"];
        $email_getting=$_POST["emo"];
        $file=addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
       
        $sql="INSERT INTO eleves SET CNE=\"$cne_getting\",NOM =\"$eduntifiant_getting\", PRENOM=\"$prenom_getting\" ,EMAIL=\"$email_getting\",PHOTO=\"$file\" ";
       
        mysqli_query($testing_connexion,$sql);
        mysqli_close($testing_connexion);
 
    endif;
?>