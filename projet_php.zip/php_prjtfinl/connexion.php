<link rel="stylesheet" href="cin.css">
<?php
session_start();
if(isset($_POST["user"]) && isset($_POST["pass"])):
$login=false;
$login_name=$_POST["user"];
$pass_login=$_POST["pass"];
require "connect_to_server.php";
if($testing_connexion==false){
    echo mysqli_connect_error();
    exit();
}
else{

    echo "la connexion est bien faite ";
    $sql="SELECT * FROM comptes WHERE login=\"$login_name\" and pass_word=\"$pass_login\" ";
    $res=mysqli_query($testing_connexion,$sql);
    mysqli_close($testing_connexion);
    if($res):
           while($table=mysqli_fetch_assoc($res)){
           $login=true;  
           $_SESSION["user"]=$login_name;
           header('location:welcom.php');
   }
endif;
   if($login==false){
       header('location:index.html?reponse=\"password or login not correct\"');
   } 
}
endif;
?>