<?php

$servername="localhost";
$db_admin="root";
$db_name="ensat";
$db_pass="";

$testing_connexion=@mysqli_connect($servername,$db_admin,$db_pass,$db_name);

