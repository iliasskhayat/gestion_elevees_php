<link rel="stylesheet" href="welcom.css">
<?php
session_start();
if(isset($_SESSION["user"])):
?>

<p><center> <b>liste des eleves de ensat 2021/2022</b> </center></p>
<?php  echo "bienvenue" . "  ".$_SESSION["user"];?>
<hr>
<a id="quit" href="déconnexion.php"> Déconnexion</a>
<?php echo "<br>";?>
<a href="ajout_etudiant.php"> ajouter un etudiant</a>
<table border="1">

    <tr>
        <th class="case">CNE</th>
        <th class="case">NOM</th>
        <th class="case">PRENOM</th>
        <th class="case">EMAIL</th>
        <th class="case">PHOTO</th> 
    </tr>
    

<?php
      require_once "connect_to_server.php";
      $sql="SELECT * FROM eleves";
      $etudiants_infos=mysqli_query($testing_connexion,$sql);
      mysqli_close($testing_connexion);
      while($res=mysqli_fetch_array($etudiants_infos)):?>
            
                  <tr>
                      <?php for($i=1;$i<5;$i++): ?>
                      <td class="case"> <?php echo $res[$i];?> </td> <?php endfor;?>
                     
                      <td  class="case"> <?php echo '<img src="data:image;base64,'.base64_encode($res['PHOTO']).' ">' ?></td>
                  </tr>
            

      <?php endwhile;?>
    </table>
      <?php endif;?>
